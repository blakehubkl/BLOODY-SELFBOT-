# Discord Selfbot 🪐

## 📹 Preview

!https://cdn.discordapp.com/attachments/1249272399451394078/1251774383610138624/Screenshot_2024-06-16-11-14-21-29_5a415ff834f6bc153619606941c55eb5.jpg?ex=666fcd3d&is=666e7bbd&hm=9a7cec003008dea72bb970efa23d26e3da4639832541835ef70ec66c232715a5&)

## 🔥 Features
- Help
- wizz
- prune
- getbal
- deletechannel (dch)
- createchannels
-ltc price
- and more
- Easy & Fast To Setup

## ✍️ Usage
1. Open `blake.py` (very esay)

## ⚠️ DISCLAIMER / NOTES
This github repo is for EDUCATIONAL PURPOSES ONLY. I am NOT under any responsibility if a problem occurs.
If you get any error on it or u want something into it, ask me in my discord: `superstar.fr`

## ✨ Issues / Doubts

- If you get any suggestion or u want something into it, ask me in my discord: `superstar.fr`
- 
Readme by @Superstar
